/* eslint-env serviceworker */
importScripts("components/serviceworker/notifications.js");

define(["jQuery"], function($) {
    "use strict";
    $.fn.selectmenu = function() {
        return this
    }
});
define(['userSettingsBuilder'], function (userSettingsBuilder) {
    'use strict';

    return new userSettingsBuilder();
});
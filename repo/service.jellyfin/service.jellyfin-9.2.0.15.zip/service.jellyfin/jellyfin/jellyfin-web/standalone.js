(function() {
    "use strict";
    window.appMode = 'standalone';
})();
